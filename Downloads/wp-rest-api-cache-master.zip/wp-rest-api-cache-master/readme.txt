=== WP REST API Cache ===
Contributors: airesvsg
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_donations&business=airesvsg%40gmail%2ecom&lc=BR&item_name=Aires%20Goncalves&no_note=0&currency_code=USD&bn=PP%2dDonationsBF%3abtn_donateCC_LG%2egif%3aNonHostedGuest
Tags: cache, rest, api, wp-api, wp-rest-api, json, wp, wordpress, wp-rest-api
Requires at least: 4.3
Tested up to: 4.9.4
Stable tag: 1.2.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Enable caching for WordPress REST API and increase speed of your application

== Description ==
Enable caching for WordPress REST API and increase speed of your application

**See details on GitHub:** http://github.com/airesvsg/wp-rest-api-cache

== Installation ==
1. Copy the `wp-rest-api-cache` folder into your `wp-content/plugins` folder
2. Activate the `WP REST API Cache` plugin via the plugin admin page

== Changelog ==

= 1.2.0 =
adding rest_cache_headers filter

= 1.1.0 =
improving the arguments of filters

= 1.0.0 =
initial version
